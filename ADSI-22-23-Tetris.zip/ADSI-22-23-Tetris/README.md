# ADSI-22-23-Tetris
Juego Tetris para práctica de asignatura Análisis y Diseño de Sistemas de Información (ADSI), curso 22-23, Grado en Ingeniería Informática de Gestión y Sistemas de Información, UPV/EHU
