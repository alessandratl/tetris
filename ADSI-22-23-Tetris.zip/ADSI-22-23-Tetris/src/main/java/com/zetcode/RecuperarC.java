package com.zetcode;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RecuperarC extends JFrame {
	
	public JPanel panel;
	
	public RecuperarC() {
		
		
		setTitle("REECUPERAR CONTRASE�A");
		setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
            
        
	
		
		this.iniciarComponentes();
		
	}
	
	private void iniciarComponentes() {
		
		panel = new JPanel();
		panel.setBackground(Color.blue);
		this.getContentPane().add(panel);
		panel.setLayout(null);
		
		this.colocarTitulo();
		
		this.colocarBotones();
		
	}
	
	private void colocarTitulo() {
		
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
		
		
		
		
	}
	
	private void colocarBotones() {
		
		JLabel recuperar = new JLabel("RECUPERAR CONTRASE�A");
		recuperar.setBounds(145,150,200,100);
		recuperar.setOpaque(true);
		recuperar.setForeground(Color.white);
		recuperar.setBackground(Color.blue);
		recuperar.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(recuperar);
		
		
		JLabel aviso = new JLabel("Si has olvidado tu contrase�a introduce tu e-mail y ");
		aviso.setBounds(100, 250, 400, 20);
		aviso.setForeground(Color.cyan);
		panel.add(aviso);
		
		JLabel aviso2 = new JLabel("te enviaremos un mensaje con instrucciones para restablecerla");
		aviso2.setBounds(80, 270, 400, 20);
		aviso2.setForeground(Color.cyan);
		panel.add(aviso2);
		
		JLabel correo = new JLabel("CORREO ELECTRONICO");
		//correo.setBorder(BorderFactory.createLineBorder(Color.black));
		correo.setBounds(60,300,200,30);
		correo.setOpaque(true);
		correo.setForeground(Color.white);
		correo.setBackground(Color.blue);
		correo.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(correo);
		

		JTextField cajaCorreo = new JTextField();
		cajaCorreo.setBounds(80, 350, 320, 30);
		panel.add(cajaCorreo);
		
		JButton enviar = new JButton("ENVIAR");
		enviar.setBounds(300,400,100,30);
		panel.add(enviar);
		
		// se deberia de implementar aqui un actio listener para envair el mail
		// o poner por pantalla que se ha enviado el mail
		
		ActionListener oyenteEnviar = new ActionListener() {
			
			//crear interfaz donde se ense�a la contrase�a con un boton aceptar y que les mande a iniciar sesion otra vez
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Sistema sis= Sistema.getSistema();
				Boolean comprobado= sis.comprobarCorreo(cajaCorreo.getText());
				
				if(comprobado) {
					String c = sis.obtenerContra(cajaCorreo.getText());
					//enviar a la interfaz
					System.out.println(c);
					MostrarContra m= new MostrarContra(cajaCorreo.getText(), c);
					m.setVisible(true);
					dispose();
					
					
				}else {
					//enviar mensaje de error
					
					errorContra e = new errorContra();
					e.setVisible(true);
					dispose();
				}
				
				
			}
		
		};
		
		enviar.addActionListener(oyenteEnviar);
		
		JButton volver = new JButton("VOLVER");
		volver.setBounds(20, 450, 90, 30);
		panel.add(volver);
			
		ActionListener oyenteVolver = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
		     
		     InicioS in = new InicioS();
		     in.setVisible(true);
		     dispose();
				
	 		
	   		}
		};
		
		volver.addActionListener(oyenteVolver);
		
		
	}
	
	
	
	
	public static void main(String[] args) {

	       

        var recuperarC = new RecuperarC();
        recuperarC.setVisible(true);
    
}

	
	

}