package com.zetcode;

import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import java.sql.*;

public class inter extends JFrame {
	public JPanel panel;
	public SGBD c = SGBD.getSGBD();
	
	public inter() {
		setTitle("Inicio");
		setSize(500,550);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		c.crearTablas();
		this.iniciarComponentes();
		
		
	}
	
	private void iniciarComponentes() {
		
		panel = new JPanel(); //crea panel
		this.getContentPane().add(panel); //a�ade panel al jframe
		panel.setLayout(null); //estamos desactivando el dise�o
		panel.setBackground(Color.blue);
//		JLabel info= new JLabel("Inicio");
//		info.setBounds(10,450,50,20);
//		info.setOpaque(true);
//		panel.add(info);
		this.colocarBotones();		
		this.colocarTitulo();
		c.crearTablas();
		
	}
	
	private void colocarBotones() {
		JButton biniciar= new JButton("Iniciar sesion");
		biniciar.setBounds(150, 220, 200, 80);
		panel.add(biniciar);
		
         ActionListener oyenteIniciar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
		     InicioS is = new InicioS();
		     is.setVisible(true);
		     dispose();
	 		
	   		}
		};
		
		biniciar.addActionListener(oyenteIniciar);
		
		JButton bregistrarse=new JButton("Registrarse");
		bregistrarse.setBounds(150, 320, 200, 80);
		panel.add(bregistrarse);
		
         ActionListener oyenteRegistrar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
		     Registrar r = new Registrar();
		      r.setVisible(true);
		     dispose();
	 		
	   		}
		};
		
		bregistrarse.addActionListener(oyenteRegistrar);
		
	}
	
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inter frame = new inter();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}}
