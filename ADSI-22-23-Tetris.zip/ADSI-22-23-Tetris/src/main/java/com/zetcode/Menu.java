package com.zetcode;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu extends JFrame {
	
	public JPanel panel;
	private String usuario;
	
	public Menu(String pUsuario){
		
	    setTitle("Menu Principal");
	    setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
       
        this.usuario = pUsuario;
        
        this.iniciarComponentes();
		
		
		
	}
	
	private void iniciarComponentes() {
		
		panel = new JPanel();
		panel.setBackground(Color.blue);
		this.getContentPane().add(panel);
		panel.setLayout(null);
		
		this.colocarTitulo();
		
		this.colocarBotones();
		
	}
	
	
	
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
		
	}
	
	private void colocarBotones() {
		
		JButton jugar = new JButton("JUGAR");
		jugar.setBounds(120, 200, 250, 60);
		panel.add(jugar);
		
		JButton personalizar = new JButton("PERSONALIZAR");
		personalizar.setBounds(165, 290, 160, 50);		
		panel.add(personalizar);
		
		JButton opciones = new JButton("OPCIONES");
		opciones.setBounds(165, 360, 160, 50);
		panel.add(opciones);
		
		ClaseO co = new ClaseO();
		
		opciones.addActionListener(co);
		
//		JButton niveles = new JButton("NIVELES");
//		niveles.setBounds(165, 430, 160, 50);
//		panel.add(niveles);
		
     	Clase c = new Clase();
		jugar.addActionListener(c);
      
		
		JButton ranking = new JButton("RANKING");
		ranking.setBounds(165, 430, 160, 50);
		panel.add(ranking);
		
		JButton salir = new JButton("SALIR");
		salir.setBounds(20,465,100,30);
		panel.add(salir);
		
		ClaseS s = new ClaseS();
		salir.addActionListener(s);
	}
	
	private class ClaseS implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			var i= new inter();
			i.setVisible(true);
			dispose();
		}
		
	}
	
	private class Clase implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					Niveles nivel = new Niveles(usuario);
					nivel.setVisible(true);
					dispose();
				}	
	}
	
	private class ClaseO implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					Opciones o = new Opciones(usuario);
					o.setVisible(true);
					dispose();
				}	
	}
	
	
	private String getUsuario() {return this.usuario;}
	
	public  void main(String[] args) {
		String usuario = this.getUsuario();
		var menu = new Menu(usuario);
	    menu.setVisible(true);
    
	}

	
	

}
