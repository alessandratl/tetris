package com.zetcode;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class error extends JFrame{
	
	
	public JPanel panel;
	
	
	public error() {
		
		setTitle("Error al iniciar sesion");
		setSize(400, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
		
		this.iniciarComponentes();
		
		
	}
	
	
	private void iniciarComponentes() {
		
		panel = new JPanel(); //crea panel
		this.getContentPane().add(panel); //a�ade panel al jframe
		panel.setLayout(null); //estamos desactivando el dise�o
		//panel.setBackground(Color.blue);
		
		JLabel texto = new JLabel("Ha habido un error al tratar de iniciar sesion con este usuario."
				);
		
		texto.setBounds(10,10,400,50);
		texto.setOpaque(true);
		
		
        JLabel texto2 = new JLabel("Comprueba los datos introducidos.");
        texto2.setOpaque(true);
        texto2.setBounds(10,10,400,120);
        
//        JLabel texto3 = new JLabel("que hayas sido previamente registrado en el juego");
//        texto3.setOpaque(true);
//        texto3.setBounds(10,10,400,130);
//        
//        JLabel texto4 = new JLabel("Si se te ha olvidado la contrase�a prueba a acceder a Recuperar Contrase�a.");
//        texto4.setOpaque(true);
//        texto4.setBounds(10,10,400,270);
//		
		
		
		panel.add(texto);
		panel.add(texto2);
//		panel.add(texto3);
//		panel.add(texto4);
		
		JButton baceptar = new JButton("Aceptar");
		baceptar.setBounds(270,80,80,25);
		panel.add(baceptar);
		
		 ActionListener oyenteAceptar = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
			     InicioS is = new InicioS();
			     is.setVisible(true);
			     dispose();
		 		
		   		}
			};
			
		baceptar.addActionListener(oyenteAceptar);
		
		
		
		
		
			
	}
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					error frame = new error();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	

}