package com.zetcode;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class BorrarUsuario extends JFrame{
	
	public JPanel panel;
	
	private String correo;
	
	public void main(String[] args) {

	       
        var borrarU = new BorrarUsuario(correo);
        borrarU.setVisible(true);
    
	}
	
	public BorrarUsuario(String pCorreo) {
			
		initialize();
		this.correo = pCorreo;
		this.colocarTitulo();
	
	}
	
	private void initialize() {
		
		setTitle("Borrar Usuario");
		setBounds(100, 100, 500, 550);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setLocationRelativeTo(null);
		panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBackground(Color.blue);
		
		
		JLabel inicio = new JLabel("Borrar Usuario");
		inicio.setBounds(145,180,200,25);
		inicio.setOpaque(true);
		inicio.setForeground(Color.white);
		inicio.setBackground(Color.blue);
		inicio.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(inicio);
		
		JLabel actual = new JLabel("NOMBRE");
		actual.setBounds(15,220,200,30);
		actual.setOpaque(true);
		actual.setForeground(Color.white);
		actual.setBackground(Color.blue);
		actual.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(actual);
		
		JTextField cajaNombre = new JTextField();
		cajaNombre.setBounds(80, 270, 320, 30);
		panel.add(cajaNombre);
		
		JLabel contra = new JLabel("CORREO");
		contra.setBounds(20,320,200,30);
		contra.setOpaque(true);
		contra.setForeground(Color.white);
		contra.setBackground(Color.blue);
		contra.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(contra);
		
		JTextField cajaCorreo = new JTextField();
		cajaCorreo.setBounds(80, 360, 320, 30);
		panel.add(cajaCorreo);
		
		JButton eliminar = new JButton("ELIMINAR");
		eliminar.setBounds(190,410,100,30);
	    panel.add(eliminar);
	    
	    ActionListener oyenteEliminar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Sistema sis= Sistema.getSistema(); 
				boolean existe= sis.comprobarCorreo(cajaCorreo.getText());
				if(!cajaCorreo.getText().equals("administrador")) {
					if(existe) {
						sis.eliminarUsuario(cajaCorreo.getText());
						var m = new AvisoEliminadoCorrectamente(correo);
						m.setVisible(true);
						dispose();
						
					}else {
						//crear una interfaz que diga que el usuario que se desea eliminar no existe
						var m  = new ErrorBorrarUsu(correo);
						m.setVisible(true);
						dispose();
						
					}
					
				} else {
					//aparece interfaz de error"no se puede eliminar este usuario"
					
					var m  = new ErrorBorrarAdmin(correo);
					m.setVisible(true);
					dispose();
				}
				
			}
		};
		
		 eliminar.addActionListener(oyenteEliminar);
	    
	   
		 JButton volver = new JButton("VOLVER");
		volver.setBounds(10, 473, 89, 29);
		 panel.add(volver);
		 ClaseV cv = new ClaseV();
		 volver.addActionListener(cv);
	}
	private class ClaseV implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					Opciones m  = new Opciones(correo);
					m.setVisible(true);
					dispose();
				}	
	}
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
	}

}
