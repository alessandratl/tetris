package com.zetcode;

	
    import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.awt.EventQueue;
	import java.awt.Graphics;
	import java.awt.Image;
	import java.net.URL;

	import javax.swing.ImageIcon;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JPanel;

	import java.awt.BorderLayout;
import java.awt.Color;

	public class Niveles extends JFrame {
		
		
		public JPanel panel;
		public Image imagenfondo;
		public URL fondo;
		
		private String usuario;
		
		
		
		
		
		public Niveles(String pUsuario) {
			
			setTitle("Niveles");
			setSize(500, 550);
	        setDefaultCloseOperation(EXIT_ON_CLOSE);
	        setLocationRelativeTo(null);
	            
	        this.usuario = pUsuario;
		
			
			this.iniciarComponentes();
			
			
		}
		
		private  void iniciarComponentes() {
			
		    panel = new JPanel(); // creamos el panel
			this.getContentPane().add(panel); // a�adimos el panel a nuestro jframe
			panel.setLayout(null); // estamos desactivando el dise�o
			//panel.setBackground(Color.BLUE);						
			this.colocarBotones();
			
			
			//this.construirFondo();
	        
			
			
			
			
		}
		
		private void colocarBotones() {
			
			JButton bfacil = new JButton("FACIL");
			bfacil.setBounds(150, 70, 200, 90);
			panel.add(bfacil);
			
			
			
			JButton bmedio = new JButton("MEDIO");
			bmedio.setBounds(150, 220, 200, 90);
			panel.add(bmedio);
												
			
			JButton bdificil = new JButton("DIFICIL");
			bdificil.setBounds(150, 370, 200, 90);
			panel.add(bdificil);
			
			JButton bvolver = new JButton("VOLVER");
			bvolver.setBounds(20, 470, 90, 30);
			panel.add(bvolver);
			
			ClaseN cn = new ClaseN();
			bvolver.addActionListener(cn);
			
			JButton bjugar = new JButton("JUGAR");
			bjugar.setBounds(370, 470, 90, 30);
			panel.add(bjugar);
			
			JLabel tetris = new JLabel(new ImageIcon("imagen2.jpeg"));
			tetris.setBounds(2, 2, 900, 900);
			panel.add(tetris);
	
			
			
			
			ActionListener oyenteFacil = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					bfacil.setBackground(Color.GREEN);	
					bmedio.setBackground(null);
					bdificil.setBackground(null);
					Sistema s = Sistema.getSistema();
					int [] t  = s.cambiarNivel(0);
	                int altura = t[0];
	        		int ancho = t[1];
	        		int velocidad = t[2];
	        		
	        		Tetris tetris = new Tetris(altura, ancho,velocidad);
	        		
	        		tetris.setVisible(true);
	        		dispose();
	        		
	 }};
	 
	 
	 bfacil.addActionListener(oyenteFacil);
	 
	 ActionListener oyenteMedio = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				bmedio.setBackground(Color.GREEN);
				bfacil.setBackground(null);
                bdificil.setBackground(null);
                Sistema s = Sistema.getSistema();
                int [] t  = s.cambiarNivel(1);
                int altura = t[0];
        		int ancho = t[1];
        		int velocidad = t[2];
        		
        		Tetris tetris = new Tetris(altura, ancho,velocidad);
        		
        		tetris.setVisible(true);
        		dispose();
        		
                
			    
				
			
}};
		
		bmedio.addActionListener(oyenteMedio);
		
		
		ActionListener oyenteDificil = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				bdificil.setBackground(Color.green);
				bmedio.setBackground(null);
				bfacil.setBackground(null);
				Sistema s = Sistema.getSistema();
				int [] t  = s.cambiarNivel(2);
                int altura = t[0];
        		int ancho = t[1];
        		int velocidad = t[2];
        		
        		Tetris tetris = new Tetris(altura, ancho,velocidad);
        		
        		tetris.setVisible(true);
        		dispose();
        		
			}
		};
		
		bdificil.addActionListener(oyenteDificil);
	 
	 
	 
			
		}
		
		
		// Al darle al boton de salir tendriamos que poner el color a null?
		// Se inicializa a algo el nivel de dificultad?
		
		
		
		
		
		
		
		
		//private void construirFondo( ) {
			
			//this.fondo = panel.getClass().getResource("/imagenes/foto.jpeg");
			//this.imagenfondo = new ImageIcon(fondo).getImage();
			//Graphics g = new Graphics();
			//g.drawImage(imagenfondo,0,0,getWidth(), getHeight(), null);
		//}
		
		private class ClaseN implements ActionListener{
			
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Menu m = new Menu(usuario);
				m.setVisible(true);
				dispose();
			}	
			
			
}
		
	
		
		
		
		public void main(String[] args) {

	       

	            var niveles = new Niveles(usuario);
	            niveles.setVisible(true);
	        
		}
		
		
		
		
		

	}
