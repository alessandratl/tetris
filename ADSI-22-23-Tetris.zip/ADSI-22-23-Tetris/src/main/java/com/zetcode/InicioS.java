package com.zetcode;
import java.awt.Color;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;



import java.sql.*;
public class InicioS extends JFrame{

	
	
	public JPanel panel;
	
	public InicioS() {
		
		
		setTitle("Inicio de Sesion");
		setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
		
		
		
		this.iniciarComponentes();
	}
	
	private void iniciarComponentes() {
		
		panel = new JPanel();
		panel.setBackground(Color.blue);
		this.getContentPane().add(panel);
		panel.setLayout(null);
		
		this.colocarTitulo();
		
		this.colocarBotones();
	}
	
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
		
		
	}
	
	private void colocarBotones() {
		
		JLabel inicio = new JLabel("INICIO DE SESION");
		inicio.setBounds(145,150,200,100);
		inicio.setOpaque(true);
		inicio.setForeground(Color.white);
		inicio.setBackground(Color.blue);
		inicio.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(inicio);
		
		
		JLabel usuario = new JLabel("USUARIO");
		usuario.setBounds(15,220,200,30);
		usuario.setOpaque(true);
		usuario.setForeground(Color.white);
		usuario.setBackground(Color.blue);
		usuario.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(usuario);
		
		JTextField cajaUsuario = new JTextField();
		cajaUsuario.setBounds(80, 270, 320, 30);
		panel.add(cajaUsuario);
		
		
		
		JLabel contra = new JLabel("CONTRASE�A");
		contra.setBounds(20,320,200,30);
		contra.setOpaque(true);
		contra.setForeground(Color.white);
		contra.setBackground(Color.blue);
		contra.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(contra);
		
		JPasswordField cajaContrase�a = new JPasswordField();
		cajaContrase�a.setBounds(80, 360, 320, 30);
		panel.add(cajaContrase�a);
		
		JButton recuperar = new JButton("RECUPERAR CONTRASE�A");
		recuperar.setBounds(20,470,200,30);
	    panel.add(recuperar);
	    
	    ActionListener oyenteRecuperar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
		     RecuperarC rc = new RecuperarC();
		     rc.setVisible(true);
		     dispose();
	 		
	   		}
		};
		
		recuperar.addActionListener(oyenteRecuperar);
	    
	    
		
		JButton entrar = new JButton("ENTRAR");
		entrar.setBounds(300,420,100,30);
		panel.add(entrar);
		
		 ActionListener oyenteEntrar = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			Sistema sis= Sistema.getSistema();
			boolean comprobado = sis.comprobarUsuario(cajaUsuario.getText(), cajaContrase�a.getText());
			
			if(comprobado) {
				Menu m = new Menu(cajaUsuario.getText());
				m.setVisible(true);
				dispose();
			}else {
				error e = new error();
				e.setVisible(true);
				dispose();
			}

			
 		
   		}
	};
	
	entrar.addActionListener(oyenteEntrar);
	
	JButton volver = new JButton("VOLVER");
	volver.setBounds(390, 473, 89, 29);
    panel.add(volver);
    ClaseVolver cv = new ClaseVolver();
    volver.addActionListener(cv);
		
	}
	
	private class ClaseVolver implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			inter m  = new inter();
			m.setVisible(true);
			dispose();
		}	
	}
	
	
	public static void main(String[] args) {

	       

        var inicioS = new InicioS();
        inicioS.setVisible(true);
        //System.out.println(System.getProperty("user.dir"));
}
	
	
	
	
}
