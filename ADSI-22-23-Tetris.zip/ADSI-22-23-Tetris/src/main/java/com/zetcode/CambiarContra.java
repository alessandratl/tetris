package com.zetcode;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

public class CambiarContra extends JFrame {

	private JPanel panel;
	
	private String usuario;

	/**
	 * Launch the application.
	 */
	public void main(String[] args) {

	       
        var CambiarContra = new CambiarContra(usuario);
        CambiarContra.setVisible(true);
    
}

	/**
	 * Create the application.
	 */
	public CambiarContra(String usu) {
		
		this.usuario = usu;
		initialize();
		this.colocarTitulo();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	private void initialize() {
		
		
		setTitle("Cambiar Contrase�a");
		setBounds(100, 100, 500, 550);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setLocationRelativeTo(null);
		panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBackground(Color.blue);
		
//		JLabel lblNewLabel = new JLabel("CAMBIAR CONTRASE�A");
//		lblNewLabel.setForeground(Color.WHITE);
//		lblNewLabel.setBounds(164, 180, 160, 70);
//		panel.add(lblNewLabel);
		
		
		JLabel inicio = new JLabel("CAMBIAR CONTRASE�A");
		inicio.setBounds(145,180,200,25);
		inicio.setOpaque(true);
		inicio.setForeground(Color.white);
		inicio.setBackground(Color.blue);
		inicio.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(inicio);
		
		
		JLabel actual = new JLabel("CONTRASE�A ACTUAL");
		actual.setBounds(15,220,200,30);
		actual.setOpaque(true);
		actual.setForeground(Color.white);
		actual.setBackground(Color.blue);
		actual.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(actual);
		
		JTextField cajaActual = new JTextField();
		cajaActual.setBounds(80, 270, 320, 30);
		panel.add(cajaActual);
		
		
		
		JLabel contra = new JLabel("CONTRASE�A NUEVA");
		contra.setBounds(20,320,200,30);
		contra.setOpaque(true);
		contra.setForeground(Color.white);
		contra.setBackground(Color.blue);
		contra.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(contra);
		
		JPasswordField cajaNueva = new JPasswordField();
		cajaNueva.setBounds(80, 360, 320, 30);
		panel.add(cajaNueva);
		
		JButton cambiar = new JButton("CAMBIAR");
		cambiar.setBounds(190,410,100,30);
	    panel.add(cambiar);
	    
	    ActionListener oyenteCambiar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Sistema sis= Sistema.getSistema(); 
				
				boolean ok= sis.comprobarUsuario(usuario, cajaActual.getText());
				if(ok) {
					sis.cambiarContra(cajaActual.getText(), cajaNueva.getText(), usuario);
					
					var bu = new AvisoCambiarContraCorrectamente(usuario);
				     bu.setVisible(true);
				     dispose();
				}else {
					var bu = new ErrorCambiarContra(usuario);
				     bu.setVisible(true);
				     dispose();
				}
				
			}
		};
		
		 cambiar.addActionListener(oyenteCambiar);
	    
	    JButton volver = new JButton("VOLVER");
		volver.setBounds(20,465,100,30);
	    panel.add(volver);
	    
	    
	    ClaseV cv = new ClaseV();
	    volver.addActionListener(cv);
	}
	
	
	
	private class ClaseV implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					Opciones o  = new Opciones(usuario);
					o.setVisible(true);
					dispose();
				}	
	}
	
	
	
	
	private void colocarTitulo() {
		
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
	}

}
