package com.zetcode;

import java.awt.Color;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;



public class Registrar extends JFrame  {
	
	public JPanel panel;
	
	
	public Registrar() {
		setTitle("Registrarse");
		setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
		this.iniciarComponentes();
	}
	

	private void iniciarComponentes() {
		
		panel = new JPanel();
		panel.setBackground(Color.blue);
		this.getContentPane().add(panel);
		panel.setLayout(null);
		
		this.colocarTitulo();
		
		this.colocarBotones();
	}
	
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
		
		
	}
	
	private void colocarBotones() {
		
		JLabel registrarse = new JLabel("REGISTRARSE"); 
		registrarse.setBounds(145,150,200,100);
		registrarse.setOpaque(true);
		registrarse.setForeground(Color.white);
		registrarse.setBackground(Color.blue);
		registrarse.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(registrarse);
		
		JLabel nombre = new JLabel("Nombre");
		nombre.setBounds(15,220,200,30);
		nombre.setOpaque(true);
		nombre.setForeground(Color.white);
		nombre.setBackground(Color.blue);
		nombre.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(nombre);
		
		JTextField cajaNombre = new JTextField();
		cajaNombre.setBounds(80, 270, 320, 30);
		panel.add(cajaNombre);
		
		
		JLabel correo = new JLabel("Correo Electronico/Usuario");
		correo.setBounds(45,320,200,30);
		correo.setOpaque(true);
		correo.setForeground(Color.white);
		correo.setBackground(Color.blue);
		correo.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(correo);
		
		JTextField cajaCorreo = new JTextField();
		cajaCorreo.setBounds(80, 350, 320, 30);
		panel.add(cajaCorreo);
		
		
		JLabel contra = new JLabel("Contrase�a");
		contra.setBounds(20,390,200,30);
		contra.setOpaque(true);
		contra.setForeground(Color.white);
		contra.setBackground(Color.blue);
		contra.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(contra);
		
		JTextField cajaContra = new JTextField();
		cajaContra.setBounds(80, 420, 320, 30);
		panel.add(cajaContra);
		
		JButton reg = new JButton("CREAR");
		reg.setBounds(150,470,200,30);
	    panel.add(reg);
	    //if (!cajaCorreo.getText().equals("") && !cajaContra.getText().equals("") && !cajaNombre.getText().equals("")) {
	    	
	    	
	    	
	    	ActionListener oyenteRegistrarse = new ActionListener() {
		    	
	    	    
		    	@Override
				public void actionPerformed(ActionEvent arg0) {
					
		    		Sistema sis= Sistema.getSistema();
		    		boolean comprobado = sis.comprobarUsuario(cajaCorreo.getText(), cajaContra.getText());
		    		
		    		if(!comprobado) {
		    			sis.registrar(cajaNombre.getText(), cajaCorreo.getText(), cajaContra.getText());
		    			//despues de registrar llevarlo a Menu prinicipal
		    			Menu m = new Menu(cajaCorreo.getText());
						m.setVisible(true);
						dispose();
		    		}else {
		    			//llevarlo a inicio porque el usuario-> msg: Parece que el usuario ya existe, intente iniciar sesi�n
		    			errorRegistro er= new errorRegistro();
		    			er.setVisible(true);
		    			dispose();
		    			
		    		}
		    	}
		    	};
		    	
		    	reg.addActionListener(oyenteRegistrarse);
	    	
	   // }else {
	    //	System.out.println("tiene que ingresar todos los datos");
	    //}
	    
	    	
	    	JButton volver = new JButton("VOLVER");
	    	volver.setBounds(10, 473, 89, 29);
	        panel.add(volver);
	        ClaseVolver cv = new ClaseVolver();
	        volver.addActionListener(cv);
	    		
	    
	   
		
	}
	
	private class ClaseVolver implements ActionListener{
		
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			inter m  = new inter();
			m.setVisible(true);
			dispose();
		}	
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registrar frame = new Registrar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

}
