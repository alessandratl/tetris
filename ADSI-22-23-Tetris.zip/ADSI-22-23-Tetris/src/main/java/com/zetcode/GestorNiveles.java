package com.zetcode;

public class GestorNiveles {
	

private static GestorNiveles miGestorNiveles =null;

private Nivel niveles[];
	
	private GestorNiveles() {
		
		this.niveles = new Nivel [3];
		Nivel facil = new Nivel(10,15,600);
		Nivel medio = new Nivel(25,30,300);
		Nivel dificil  = new Nivel(45,60,100);
		
		niveles[0] = facil;
		niveles[1] = medio;
		niveles[2] = dificil;
		
	}
	
	public static GestorNiveles getGestorNiveles() {
		if(GestorNiveles.miGestorNiveles==null) {
			GestorNiveles.miGestorNiveles= new GestorNiveles();
		}
		return (GestorNiveles.miGestorNiveles);
	}
	
	public Nivel[] getNiveles() {
		
		return this.niveles;
	}
	

}