package com.zetcode;

public class Sistema {
	private static Sistema miSistema=null; 
	public gestorUsuario GU= gestorUsuario.getGestorU();
	private Sistema() {
		
	}
	
	public static Sistema getSistema() {
		if(Sistema.miSistema==null) {
			Sistema.miSistema= new Sistema();
		}
		return (Sistema.miSistema);
	}
	
	public boolean comprobarUsuario(String correo, String pswd) {
		
		return GU.coincideUsuario(correo, pswd);
		
	}
	
	public void registrar(String nombre, String correo, String psw) {
		
		
		GU.registrar(nombre, correo, psw);
		
		
	}
	
	public boolean comprobarCorreo(String correo) {
		
		return GU.comprobarCorreo(correo);
	}
	
	public String obtenerContra(String correo) {
		
		return GU.obtenerContra(correo);
	}

	public void cambiarContra(String vieja, String nueva, String correo) {
		GU.cambiarContra(vieja, nueva, correo);
	}
	
	public void eliminarUsuario(String pCorreo) {
		GU.eliminarUsuario(pCorreo);
	}
	
	public int[] cambiarNivel(int nivel) {
		
		// en el caso de que sea 0 sera facil
		// en el caso de que sea 1 sera medio
		// en el caso de que sea 2 sera dificil
		
		GestorNiveles gn = GestorNiveles.getGestorNiveles();
		
		Nivel[] n = gn.getNiveles();
		
		Nivel miNivel = n[nivel];
		
		int[] d = miNivel.getDatos();
		
		return d;
		
//		int altura = d[0];
//		int ancho = d[1];
//		int velocidad = d[2];
//		
//		Tetris t = new Tetris(altura, ancho,velocidad);
//		
//		return t; 
		}
	
	
}
