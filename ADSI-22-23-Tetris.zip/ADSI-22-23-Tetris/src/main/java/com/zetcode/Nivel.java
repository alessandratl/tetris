package com.zetcode;

public class Nivel {
	
	
	private int altura;
	private int ancho;
	private int velocidad;
	
	public Nivel(int pAltura, int pAncho, int  pVelocidad) {
		
		this.altura = pAltura;
		this.ancho = pAncho;
		this.velocidad = pVelocidad;
	}
	
	public  int [] getDatos() {
		
		int [] datos = new int[3];
		
		datos[0] = altura;
		datos[1] = ancho;
		datos[2] = velocidad;
		
		return datos;
		
		
		
		
		
	}
	
	
	
	
//	public void setDimensiones(int x , int y ) {
//		
//		this.altura = x;
//		this.ancho = y;
//	}
//	
//	public void setVelocidad(float v) {
//		
//		this.velocidad = v;
//	}

}