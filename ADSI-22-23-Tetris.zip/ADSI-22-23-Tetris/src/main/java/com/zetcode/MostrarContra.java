package com.zetcode;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MostrarContra extends JFrame{
	
	
	public JPanel panel;
	private String usuario;
	private String contra;
	
	public MostrarContra(String pCorreo, String pContra) {
		
		setTitle("Mostrar Contrase�a");
	    setSize(500, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        this.usuario = pCorreo;
        
        this.contra = pContra;
        
        this.iniciarComponentes();
			
	}
	
	private void iniciarComponentes() {
		
		panel = new JPanel();
		panel.setBackground(Color.blue);
		this.getContentPane().add(panel);
		panel.setLayout(null);
		
		this.colocarTitulo();
		this.colocarBotones();
	}
	
	private void colocarTitulo() {
		
		JLabel tetris = new JLabel(new ImageIcon("imagen.jpeg"));
		tetris.setBounds(52, 5, 400, 200);
		panel.add(tetris);
		
	}
	
	private void colocarBotones() {
		
		JLabel texto = new JLabel("La contrase�a de"+this.usuario+ "es la siguiente:");
		texto.setBounds(10,10,400,50);
		texto.setOpaque(true);
		
		 JLabel texto2 = new JLabel(this.contra);
		 texto2.setOpaque(true);
		 texto2.setBounds(10,10,400,120);
		 
		 panel.add(texto);
		 panel.add(texto2);
		 
		 JButton baceptar = new JButton("Aceptar");
		 baceptar.setBounds(270,80,80,25);
		 panel.add(baceptar);
		 
		 ActionListener oyenteAceptar = new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						
				     InicioS is = new InicioS();
				     is.setVisible(true);
				     dispose();
			 		
			   		}
				};
				
				baceptar.addActionListener(oyenteAceptar);
	       
	}
	
	private String getUsuario() {return this.usuario;}
	private String getContra() { return this.contra;}
	
	public void main(String[] args) {
		
		String u= this.getUsuario();
		String contra= this.getContra();
		
		var mostrarC = new MostrarContra(u, contra);
		mostrarC.setVisible(true);
		
	}
	
	

}
