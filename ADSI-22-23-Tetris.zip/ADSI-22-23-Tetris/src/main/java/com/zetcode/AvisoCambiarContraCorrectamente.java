package com.zetcode;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AvisoCambiarContraCorrectamente extends JFrame{

	public JPanel panel;
	private String correo;
	public AvisoCambiarContraCorrectamente(String pCorreo) {
		
		setTitle("Contrase�a cambiada correctamente");
		setSize(400, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
		this.correo=pCorreo;
		this.iniciarComponentes();	
	}
	
	private void iniciarComponentes() {
		panel = new JPanel(); //crea panel
		this.getContentPane().add(panel); //a�ade panel al jframe
		panel.setLayout(null); //estamos desactivando el dise�o
		//panel.setBackground(Color.blue);
		
		JLabel texto = new JLabel("Se ha cambiado la contrase�a correctamente");
		
		texto.setBounds(10,10,400,50);
		texto.setOpaque(true);
		
		panel.add(texto);
		
		JButton baceptar = new JButton("Aceptar");
		baceptar.setBounds(270,80,80,25);
		panel.add(baceptar);
		
		ActionListener oyenteAceptar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
		     var bu = new CambiarContra(correo);
		     bu.setVisible(true);
		     dispose();
	 		
	   		}
		};
		
		baceptar.addActionListener(oyenteAceptar);
	}
	
	public void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					var frame = new AvisoCambiarContraCorrectamente(correo);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
}
