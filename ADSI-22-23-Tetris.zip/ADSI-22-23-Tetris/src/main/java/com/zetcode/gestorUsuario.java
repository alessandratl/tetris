package com.zetcode;

public class gestorUsuario {
	
	
	
	private static gestorUsuario miGestorU=null; 
	private SGBD BD = SGBD.getSGBD();
	private gestorUsuario() {
		
	}
	
	public static gestorUsuario getGestorU() {
		if(gestorUsuario.miGestorU==null) {
			gestorUsuario.miGestorU= new gestorUsuario();
		}
		return (gestorUsuario.miGestorU);
	}
	
	public boolean coincideUsuario(String correo, String pswd) {
		
		return BD.coincideUsuario(correo, pswd);
		
	}
	
	public void registrar(String nombre, String correo, String psw) {
		BD.registrar(nombre, correo, psw);
	}
	
	public boolean comprobarCorreo(String correo) {
		
		return BD.comprobarCorreo(correo);
	}
	
	public String obtenerContra(String correo) {
		
		return BD.obtenerContra(correo);
	}
	
	public void cambiarContra(String vieja, String nueva, String correo) {
		BD.cambiarContra(vieja, nueva, correo);
	}
	
	public void eliminarUsuario(String pCorreo) {
		BD.eliminarUsuario(pCorreo);
	}
}
