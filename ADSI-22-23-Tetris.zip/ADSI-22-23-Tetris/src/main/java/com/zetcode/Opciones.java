package com.zetcode;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Opciones extends JFrame {

	
	public JPanel panel;
	private String usuario;

	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the application.
	 */
	public Opciones(String usu) {
		this.usuario = usu;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		setTitle("Opciones");
		setBounds(100, 100, 500, 550);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		panel = new JPanel();
		this.getContentPane().add(panel);
		panel.setLayout(null);
		panel.setBackground(Color.blue);
		
		JButton btnCambiarContra = new JButton("CAMBIAR CONTRASE�A");
		
		ClaseCC cc = new ClaseCC();
		
		btnCambiarContra.addActionListener(cc);
		
//        ActionListener oyenteContrase�a = new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent arg0) {
//				
//		     CambiarContrase�a cc = new CambiarContrase�a();
//		     cc.setVisible(true);
//		     dispose();
//	 		
//	   		}
//		};
		
		btnCambiarContra.setBounds(126, 268, 225, 72);
		panel.add(btnCambiarContra);
		if (this.usuario.equals("administrador")) {
			JButton borrarUsu = new JButton("BORRAR USUARIO");
			borrarUsu.setBounds(126, 372, 225, 72);
			panel.add(borrarUsu);
			
			ClaseBorrarUsu cbu = new ClaseBorrarUsu();
			borrarUsu.addActionListener(cbu);
		}
		
		
		//JButton btnOpcion3 = new JButton("OPCION 3");
		
		//btnOpcion3.setBounds(126, 268, 225, 72);
		//panel.add(btnOpcion3);
		
		//JButton btnOpcion4 = new JButton("OPCION 4");
		//btnOpcion4.setBounds(126, 372, 225, 72);
		//panel.add(btnOpcion4);
		
		JButton btnVolver = new JButton("VOLVER");
		btnVolver.setBounds(10, 473, 89, 29);
		panel.add(btnVolver);
		
		
		
		ClaseV cv = new ClaseV();
		
		btnVolver.addActionListener(cv);
	}
	
	private class ClaseBorrarUsu implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			
			BorrarUsuario m  = new BorrarUsuario(usuario);
			m.setVisible(true);
			dispose();
		}	
	}
	
	private class ClaseV implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					Menu m  = new Menu(usuario);
					m.setVisible(true);
					dispose();
				}	
	}
	
	private class ClaseCC implements ActionListener{
		// aqui lo que estamos haciendo es abrir la interfaz de escoger la dificulta de juego antes
		// de ponerse a jugar
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					CambiarContra cc  = new CambiarContra(usuario);
					cc.setVisible(true);
					dispose();
				}	
	}
	
	public void main(String[] args) {

	       
        var Opciones = new Opciones(usuario);
        Opciones.setVisible(true);
    
}
}
