package com.zetcode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class SGBD {
	private static SGBD miSGBD= null;
	//private Connection bd;
	
	//private Conexion bd;
	
	private SGBD() {
		//try {
			//bd= DriverManager.getConnection("jdbc:mariadb://localhost:3306/bdtetris", "root", "");
			//bd= new Conexion();
			//} catch (SQLException e) {
				//System.out.println("Ha habido un error al vincular la base de datos");
			//}
		
			
	}
	
	public void crearTablas() {
		
		Connection bd=conectar();
		try {
			bd.prepareStatement("CREATE TABLE dificultad(nivelDificultad�VARCHAR(10), velocidad INT, PRIMARY KEY(nivelDificultad))").execute();
			bd.prepareStatement("CREATE TABLE usuario(idUsuario VARCHAR(10), nombre VARCHAR(20), contrase�a VARCHAR(20), correo VARCHAR(30), sonido VARCHAR(10), color VARCHAR(10), ladrillo�VARCHAR(10), PRIMARY KEY(correo,idUsuario))").execute();
			bd.prepareStatement("CREATE TABLE puntuacion (idPuntuacion�VARCHAR(10), nivelDificultad VARCHAR(10), puntos INT, PRIMARY KEY(idPuntuacion), FOREIGN KEY (nivelDificultad) REFERENCES dificultad(nivelDificultad)��ON DELETE CASCADE ON UPDATE CASCADE�)").execute();
			bd.prepareStatement("CREATE TABLE tablero (idTablero VARCHAR(10), tama�oX INT, tama�oY INT, PRIMARY KEY(idTablero))").execute();
			bd.prepareStatement("CREATE TABLE resultado(idUsuario VARCHAR(10), idPuntuacion VARCHAR(10),PRIMARY KEY(idUsuario, idPuntuacion),FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE,FOREIGN KEY(idPuntuacion) REFERENCES puntuacion(idPuntuacion) ON DELETE CASCADE ON UPDATE CASCADE)").execute();
			bd.prepareStatement("CREATE TABLE partida (idPartida VARCHAR(10), idUsuario VARCHAR(10), nivelDificultad VARCHAR(10), idTablero VARCHAR(10), PRIMARY KEY(idPartida), FOREIGN KEY(idUsuario) REFERENCES usuario(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE,FOREIGN KEY(nivelDificultad) REFERENCES dificultad(nivelDificultad) ON DELETE CASCADE ON UPDATE CASCADE,FOREIGN KEY(idTablero) REFERENCES tablero(idTablero) ON DELETE CASCADE ON UPDATE CASCADE)").execute();
			//bd.prepareStatement("INSERT INTO usuario(idUsuario,nombre, contrase�a, correo) VALUES(1,administrador,administrador,administrador)").executeUpdate();
		}catch(Exception ex) {
			System.out.println("Error"+ex);
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
	}
	
	public Connection conectar() {
		//Connection con=null;
		Connection bd=null;
		try {
			Class.forName("org.h2.Driver");
			bd = DriverManager.getConnection("jdbc:h2:file:C:\\Users\\aless\\git\\ADSI-22-23-Tetris\\bd\\tetris","alessandra","");
			System.out.println("En linea");
		
		} catch (Exception ex) {
			System.out.println("Error"+ex);
		}
		return bd;
	}
	
	public static SGBD getSGBD() {
		if (SGBD.miSGBD==null) {
			SGBD.miSGBD= new SGBD();
		}
		
		return(SGBD.miSGBD);
		
	}
	
	public void cerrarConexion() {
		Connection bd= conectar();
		try {
			bd.close(); //cierra conexion con la bd
			} catch (SQLException e) {
				System.out.println("No se ha podido cerrar conexion");
			}finally {
				try {
					bd.close();
				}catch(Exception ex) {
					
				}
			}
	}
	
	//public Connection getBD() {
		//return this.bd; 
	//}
	
	public boolean coincideUsuario(String correo, String pswd) {
		Connection bd=conectar();
		boolean existe=false;
		try {
			ResultSet persona = bd.prepareStatement("SELECT * FROM usuario  WHERE correo = '"+correo+"' AND contrase�a='"+pswd+"'").executeQuery();
			existe= persona.next();	
			//persona.close();
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}finally {
				try {
					bd.close();
				}catch(Exception ex) {
					
				}
			}
		}
		
		return existe;
		
		
	}
	
	public void registrar(String nombre, String correo, String psw) {
		Connection bd=conectar();
		try {
			bd.prepareStatement("INSERT INTO usuario(nombre, contrase�a, correo) values('"+nombre+"','"+psw+"','"+correo+"')").executeUpdate();
			//persona.close();
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
		
	}
	
	public boolean comprobarCorreo(String correo) {
		Connection bd=conectar();
		boolean comprobado=false;
		
		try {
			ResultSet persona = bd.prepareStatement("SELECT * FROM usuario  WHERE correo = '"+correo+"'").executeQuery();
			comprobado= persona.next();	
			//persona.close();
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
		
		return comprobado;
	}
	
	public String obtenerContra(String correo) {
		Connection bd=conectar();
		String contra=null;
		boolean comprobado=false;
		try {
			ResultSet persona = bd.prepareStatement("SELECT * FROM usuario  WHERE correo = '"+correo+"'").executeQuery();
			comprobado= persona.next();	
			contra=persona.getString("contrase�a");
			//persona.close();
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
		
		return contra;
	}
	
	
	
	public void cambiarContra(String vieja, String nueva, String correo) {
		
		Connection bd=conectar();
		try {
			bd.prepareStatement("UPDATE USUARIO SET contrase�a= '"+nueva+"' WHERE correo='"+correo+"' AND contrase�a='"+vieja+"'").executeUpdate();
			
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
		
	}
	
	public void eliminarUsuario(String pCorreo) {
		Connection bd=conectar();
		try {
			bd.prepareStatement("DELETE FROM USUARIO WHERE correo='"+pCorreo+"'").executeUpdate();
			
		}catch (SQLException e) {
			System.out.println("Ha habido un error ");
		}finally {
			try {
				bd.close();
			}catch(Exception ex) {
				
			}
		}
		
		
		
	}
	
}
